// src/app/todo/todo.component.ts
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms'; // ✅ Import this for template use

@Component({
  selector: 'app-todo',
  standalone: true,
  imports: [CommonModule, FormsModule], // ✅ Required for *ngFor, [(ngModel)]
  templateUrl: './todo.component.html',
  styleUrls: ['./todo.component.css']
})
export class TodoComponent {
  tasks: { id: number, task: string }[] = [];
  newTask: string = '';

  addTask() {
    if (this.newTask.trim()) {
      this.tasks.push({ id: Date.now(), task: this.newTask });
      this.newTask = '';
    }
  }

  deleteTask(id: number) {
    this.tasks = this.tasks.filter(t => t.id !== id);
  }

  editTask(task: { id: number, task: string }) {
    this.newTask = task.task;
    this.deleteTask(task.id);
  }
}
